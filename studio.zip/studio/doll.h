#pragma once
void dollInit();
void dollRun(bool keyNow);   // keyNow = 当前是否有键按住(用来触发炸开)
void dollFree();             // 释放 sprite 内存(离开人偶时)
