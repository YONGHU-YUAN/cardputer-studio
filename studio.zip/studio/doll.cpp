// 粒子人偶 — 移植到 STUDIO (LovyanGFX 版, 无 M5Unified)
#include <Arduino.h>
#include "Display.h"
#include "points.h"
#include "doll.h"

extern LGFX lcd;
static LGFX_Sprite spr(&lcd);

static const int SW=240, SH=135;
static const float CX=SW*0.5f, CY=SH*0.5f, FIT=SH*0.92f;
static const int DENSITY=2;
static const float JITTER=0.002f, COMPACT=0.88f;
static const int TOTAL=NUM_PTS*DENSITY;

struct P{ float tx,ty,tz, x,y,z, vx,vy,vz; };
static P parts[TOTAL];
static int order[TOTAL];
static float depthBuf[TOTAL];

static const float STIFFNESS=1.8f, DAMPING=3.5f, ROT_SPEED=0.55f;
static float angle=0; static uint32_t lastMs=0, lastPress=0; static bool prevKey=false;

static inline float frand(float a,float b){ return a+(float)random(0,10000)/10000.0f*(b-a); }

static void initParticles(){
  for(int i=0;i<TOTAL;i++){ P&p=parts[i]; int base=i%NUM_PTS;
    float jx=(i<NUM_PTS)?0:frand(-JITTER,JITTER), jy=(i<NUM_PTS)?0:frand(-JITTER,JITTER), jz=(i<NUM_PTS)?0:frand(-JITTER,JITTER);
    p.tx=(PTS[base*3+0]/10000.0f)*COMPACT+jx; p.ty=(PTS[base*3+1]/10000.0f)*COMPACT+jy; p.tz=(PTS[base*3+2]/10000.0f)*COMPACT+jz;
    float a=frand(0,2*PI),b=frand(0,PI),r=frand(0.6f,1.2f);
    p.x=sinf(b)*cosf(a)*r; p.y=sinf(b)*sinf(a)*r; p.z=cosf(b)*r; p.vx=p.vy=p.vz=0; }
}

void dollInit(){
  spr.setColorDepth(16);
  if(!spr.getBuffer()) spr.createSprite(SW,SH);
  randomSeed(esp_random());
  initParticles(); lastMs=millis(); prevKey=false;
}
void dollFree(){ if(spr.getBuffer()) spr.deleteSprite(); }

void dollRun(bool keyNow){
  uint32_t now=millis();
  if(keyNow && !prevKey){
    uint32_t since=now-lastPress; lastPress=now;
    float ratio=(since<400)?0.45f:0.18f;
    for(int i=0;i<TOTAL;i++) if(frand(0,1)<ratio){
      float dx=parts[i].x,dy=parts[i].y,dz=parts[i].z; float len=sqrtf(dx*dx+dy*dy+dz*dz)+0.001f;
      float burst=frand(2.5f,6.0f);
      parts[i].vx+=dx/len*burst+frand(-0.5f,0.5f); parts[i].vy+=dy/len*burst+frand(-0.5f,0.5f); parts[i].vz+=dz/len*burst+frand(-0.5f,0.5f); }
  }
  prevKey=keyNow;

  float dt=(now-lastMs)/1000.0f; if(dt>0.05f)dt=0.05f; lastMs=now; angle+=ROT_SPEED*dt;
  for(int i=0;i<TOTAL;i++){ P&p=parts[i];
    float ax=(p.tx-p.x)*STIFFNESS-p.vx*DAMPING, ay=(p.ty-p.y)*STIFFNESS-p.vy*DAMPING, az=(p.tz-p.z)*STIFFNESS-p.vz*DAMPING;
    p.vx+=ax*dt; p.vy+=ay*dt; p.vz+=az*dt; p.x+=p.vx*dt; p.y+=p.vy*dt; p.z+=p.vz*dt; }

  float ca=cosf(angle), sa=sinf(angle);
  for(int i=0;i<TOTAL;i++){ depthBuf[i]=parts[i].x*sa+parts[i].z*ca; order[i]=i; }
  for(int i=1;i<TOTAL;i++){ int k=order[i]; float dk=depthBuf[k]; int j=i-1;
    while(j>=0 && depthBuf[order[j]]>dk){ order[j+1]=order[j]; j--; } order[j+1]=k; }

  if(!spr.getBuffer()) return;
  spr.fillScreen(0);
  for(int oi=0;oi<TOTAL;oi++){ int i=order[oi]; P&p=parts[i];
    float rx=p.x*ca-p.z*sa, depth=depthBuf[i];
    int sx=(int)(CX+rx*FIT), sy=(int)(CY-p.y*FIT);
    if(sx<0||sx>=SW||sy<0||sy>=SH) continue;
    float dn=(depth+0.3f)/0.6f; if(dn<0)dn=0; if(dn>1)dn=1; float a=0.3f+0.7f*dn;
    uint16_t core=spr.color565((uint8_t)(120*a),(uint8_t)(255*a),(uint8_t)(150*a));
    if(depth>0.05f){ uint16_t glow=spr.color565((uint8_t)(20*a),(uint8_t)(120*a),(uint8_t)(50*a));
      spr.drawPixel(sx-1,sy,glow); spr.drawPixel(sx+1,sy,glow); spr.drawPixel(sx,sy-1,glow); spr.drawPixel(sx,sy+1,glow);
      spr.fillRect(sx,sy,2,2,core);
    } else spr.drawPixel(sx,sy,core);
  }
  spr.pushSprite(0,0);
}
