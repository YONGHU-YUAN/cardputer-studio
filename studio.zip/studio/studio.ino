// =====================================================================
//  STUDIO — 无 M5Unified 的二合一固件: 采样器 + 录音机 (同一固件!)
//  框架: LovyanGFX(屏) + I2C键盘(0x34) + ES8311(老式i2s 录+放) + SD
//  录音用 I2S0(RX), 播放用 I2S1(TX); 都不依赖 M5Unified -> 麦克风能录!
// =====================================================================
#include <Wire.h>
#include <SPI.h>
#include <SD.h>
#include "driver/i2s.h"
#include "Display.h"
#include "CardputerKeyboard.h"
#include "ES8311Audio.h"
#include "doll.h"
#include "synth_engine.h"
#include "seq.h"

LGFX lcd;
LGFX_Sprite ui(&lcd);           // 菜单/列表页的离屏画布(防闪屏)
void uiMake(){ if(!ui.getBuffer()){ ui.setColorDepth(16); ui.createSprite(240,135); } }
void uiFree(){ if(ui.getBuffer()) ui.deleteSprite(); }
CardputerKeyboard kb;
ES8311Audio audio;
SPIClass sdSPI(HSPI);            // SD 用独立 SPI3, 避开屏幕的 SPI2

#define SD_SCK 40
#define SD_MISO 39
#define SD_MOSI 14
#define SD_CS  12
#define PIN_SCLK 41
#define PIN_LRCK 43
#define PIN_DIN  46
static const uint32_t SR=16000;
static const int REC_MAX_SEC=20;
char recMsg[28]="";

uint16_t BG,INK,GREY,ACC,HL,RED,SEL,CARD,LINE;
enum St{ MENU, SAMPLER, RECORDER, LIBRARY, DOLL, SYNTH, SONGS } st=MENU;
int libSel=0; bool renaming=false, confirmDel=false; char nameBuf[20]="";
bool sdOK=false;
// ---- 乐曲库 ----
#define NSLOT 16
int songSel=0; bool songFilled[NSLOT]; int previewSlot=-1;
char songNames[NSLOT][16];

// ---- 样本库 ----
#define MAXS 99
char  sName[MAXS][24];
char  sPath[MAXS][72];
int   sN=0, sCur=0, sPage=0;
int16_t* sBuf=NULL; uint32_t sLen=0, sRate=SR; int sLoaded=-1;
char loadDiag[48]="";          // 最近一次载入的诊断(格式/原因)

// ---- 录音缓冲 ----
int16_t* rBuf=NULL; uint32_t rCap=0, rLen=0; bool recording=false; uint32_t recT0=0; int32_t recPeak=0; int32_t recMaxPk=0;
File recFile; uint32_t recFrames=0; char recPath[40]="";   // 边录边写卡
int32_t pkL=0,pkR=0; char diag[40]="";

const char* NOTEKEYS[]={"z","s","x","d","c","v","g","b","h","n","j","m","q","w","e","r","t","y","u","i","o","p"};
int midiOfKey(const char* k){
  static const char* names[]={"z","s","x","d","c","v","g","b","h","n","j","m","q","w","e","r","t","y","u","i","o","p"};
  static const int mid[]={60,61,62,63,64,65,66,67,68,69,70,71,72,74,76,77,79,81,83,84,86,88};
  for(int i=0;i<22;i++) if(strcmp(k,names[i])==0) return mid[i];
  return -1;
}

// ---------- WAV ----------
bool loadWav(const char* path){
  if(sBuf){ free(sBuf); sBuf=NULL; }
  File f=SD.open(path,FILE_READ); if(!f){ strcpy(loadDiag,"cannot open file"); return false; }
  uint8_t h[12]; if(f.read(h,12)!=12||memcmp(h,"RIFF",4)||memcmp(h+8,"WAVE",4)){ strcpy(loadDiag,"not a WAV file"); f.close();return false;}
  uint16_t ch=1,bits=16; uint32_t rate=SR,dOff=0,dSz=0;
  while(f.available()>=8){ uint8_t c[8]; if(f.read(c,8)!=8)break;
    uint32_t cs=c[4]|(c[5]<<8)|(c[6]<<16)|((uint32_t)c[7]<<24);
    if(!memcmp(c,"fmt ",4)){ uint8_t fm[16]; uint32_t tr=cs<16?cs:16; f.read(fm,tr);
      ch=fm[2]|(fm[3]<<8); rate=fm[4]|(fm[5]<<8)|(fm[6]<<16)|((uint32_t)fm[7]<<24); bits=fm[14]|(fm[15]<<8);
      if(cs>16)f.seek(f.position()+(cs-16)); if(cs&1)f.seek(f.position()+1);
    } else if(!memcmp(c,"data",4)){ dOff=f.position(); dSz=cs; break; }
    else f.seek(f.position()+cs+(cs&1)); }
  if(dOff==0||dSz==0||bits!=16||ch<1||ch>2){ snprintf(loadDiag,48,"need 16-bit, this is %d-bit %dch",bits,ch); f.close();return false;}
  uint32_t fsz=f.size(); if(dOff+dSz>fsz)dSz=fsz-dOff;
  uint32_t frames=dSz/(2*ch); if(frames==0){ strcpy(loadDiag,"empty (0 samples)"); f.close();return false;}
  sBuf=(int16_t*)ps_malloc(frames*2); if(!sBuf)sBuf=(int16_t*)malloc(frames*2);
  if(!sBuf){ snprintf(loadDiag,48,"OUT OF MEMORY (%lu KB)",(unsigned long)(frames*2/1024)); f.close();return false;}
  f.seek(dOff); static int16_t tmp[512*2]; uint32_t got=0;
  while(got<frames){ uint32_t want=frames-got; if(want>512)want=512;
    int rd=f.read((uint8_t*)tmp,want*2*ch); uint32_t fr=rd/(2*ch); if(fr==0)break;
    for(uint32_t i=0;i<fr;i++) sBuf[got+i]= ch==1? tmp[i] : (int16_t)((tmp[i*2]+tmp[i*2+1])/2);
    got+=fr; }
  f.close(); sLen=got; sRate=rate; snprintf(loadDiag,48,"ok %d-bit %dch %luHz",bits,ch,(unsigned long)rate); return true;
}
void w16(File&f,uint16_t v){f.write((uint8_t)(v&0xff));f.write((uint8_t)(v>>8));}
void w32(File&f,uint32_t v){for(int i=0;i<4;i++)f.write((uint8_t)((v>>(8*i))&0xff));}
void saveWav(const char* path,int16_t* buf,uint32_t n){
  File f=SD.open(path,FILE_WRITE); if(!f)return;
  uint32_t d=n*2; f.write((const uint8_t*)"RIFF",4); w32(f,36+d); f.write((const uint8_t*)"WAVE",4);
  f.write((const uint8_t*)"fmt ",4); w32(f,16); w16(f,1); w16(f,1); w32(f,SR); w32(f,SR*2); w16(f,2); w16(f,16);
  f.write((const uint8_t*)"data",4); w32(f,d);
  uint32_t i=0; while(i<n){ uint32_t c=n-i; if(c>512)c=512; f.write((uint8_t*)(buf+i),c*2); i+=c; }
  f.close();
}

// ---------- SD 扫描 ----------
void scanDir(const char* dir){
  File root=SD.open(dir); if(!root||!root.isDirectory()){if(root)root.close();return;}
  File e;
  while(sN<MAXS && (e=root.openNextFile())){
    const char* n=e.name();
    if(!e.isDirectory()){ const char* d=strrchr(n,'.');
      if(d&&(!strcmp(d,".wav")||!strcmp(d,".WAV"))&&n[0]!='.'){
        if(n[0]=='/') snprintf(sPath[sN],72,"%s",n); else snprintf(sPath[sN],72,"%s/%s",dir,n);
        strncpy(sName[sN],strrchr(sPath[sN],'/')+1,23); sName[sN][23]=0;
        char* dot=strrchr(sName[sN],'.'); if(dot)*dot=0; sN++; } }
    e.close(); }
  root.close();
}
void sortSamples(){   // 按名字字母排序(不分大小写), 便于查找
  for(int i=1;i<sN;i++){ char tn[24]; char tp[72]; strcpy(tn,sName[i]); strcpy(tp,sPath[i]); int j=i-1;
    while(j>=0 && strcasecmp(sName[j],tn)>0){ strcpy(sName[j+1],sName[j]); strcpy(sPath[j+1],sPath[j]); j--; }
    strcpy(sName[j+1],tn); strcpy(sPath[j+1],tp); }
}
void rescan(){ sN=0; scanDir("/samples"); scanDir("/VoiceMemos"); if(sN==0)scanDir("/"); sortSamples(); if(sCur>=sN)sCur=0; }

// ---------- 录音 (I2S0 RX -> 边录边写 TF 卡, 几乎不占内存) ----------
void recStart(){
  if(!sdOK){ strcpy(recMsg,"no SD"); return; }
  if(sBuf){ free(sBuf); sBuf=NULL; sLoaded=-1; }      // 腾内存
  if(rBuf){ free(rBuf); rBuf=NULL; }                  // 不再用大缓冲
  recMsg[0]=0;
  SD.mkdir("/samples");
  for(int i=1;i<999;i++){ snprintf(recPath,40,"/samples/REC%d.wav",i); if(!SD.exists(recPath))break; }
  recFile=SD.open(recPath,FILE_WRITE);
  if(!recFile){ strcpy(recMsg,"SD open fail"); return; }
  // 写占位 WAV 头(数据大小先填0, 停止时回填)
  recFile.write((const uint8_t*)"RIFF",4); w32(recFile,36); recFile.write((const uint8_t*)"WAVE",4);
  recFile.write((const uint8_t*)"fmt ",4); w32(recFile,16); w16(recFile,1); w16(recFile,1); w32(recFile,SR); w32(recFile,SR*2); w16(recFile,2); w16(recFile,16);
  recFile.write((const uint8_t*)"data",4); w32(recFile,0);
  bool codec=audio.testConnection();
  audio.enableMicForStream();
  i2s_config_t c={}; c.mode=(i2s_mode_t)(I2S_MODE_MASTER|I2S_MODE_RX);
  c.sample_rate=SR; c.bits_per_sample=I2S_BITS_PER_SAMPLE_16BIT;
  c.channel_format=I2S_CHANNEL_FMT_RIGHT_LEFT; c.communication_format=I2S_COMM_FORMAT_STAND_I2S;
  c.intr_alloc_flags=ESP_INTR_FLAG_LEVEL1; c.dma_buf_count=8; c.dma_buf_len=128;
  c.use_apll=false; c.tx_desc_auto_clear=true; c.mclk_multiple=I2S_MCLK_MULTIPLE_256; c.bits_per_chan=I2S_BITS_PER_CHAN_16BIT;
  esp_err_t ie=i2s_driver_install(I2S_NUM_0,&c,0,NULL);
  if(ie!=ESP_OK){ snprintf(diag,sizeof(diag),"codec=%s i2s=ERR",codec?"OK":"NO"); strcpy(recMsg,"i2s install fail"); if(recFile)recFile.close(); return; }   // 安装失败: 不进入录音状态
  i2s_pin_config_t p={}; p.mck_io_num=I2S_PIN_NO_CHANGE; p.bck_io_num=PIN_SCLK; p.ws_io_num=PIN_LRCK; p.data_out_num=I2S_PIN_NO_CHANGE; p.data_in_num=PIN_DIN;
  i2s_set_pin(I2S_NUM_0,&p); i2s_zero_dma_buffer(I2S_NUM_0);
  snprintf(diag,sizeof(diag),"codec=%s i2s=%s", codec?"OK":"NO", ie==ESP_OK?"OK":"ERR");
  static int16_t dsc[256]; size_t br; for(int i=0;i<5;i++) i2s_read(I2S_NUM_0,dsc,sizeof(dsc),&br,80/portTICK_PERIOD_MS);
  recFrames=0; recPeak=0; recMaxPk=0; recording=true; recT0=millis();
}
void recPump(){
  static int16_t stx[256*2]; static int16_t mono[256]; size_t br=0;
  uint32_t maxFrames=(uint32_t)REC_MAX_SEC*SR;
  i2s_read(I2S_NUM_0,stx,sizeof(stx),&br,20/portTICK_PERIOD_MS);
  int got=br/4; int32_t pl=0,pr=0; int mn=0;
  for(int i=0;i<got && recFrames<maxFrames;i++){ int16_t L=stx[i*2], R=stx[i*2+1];
    int32_t al=L<0?-L:L, ar=R<0?-R:R; if(al>pl)pl=al; if(ar>pr)pr=ar;
    mono[mn++]=(ar>=al)?R:L; recFrames++; }          // 较响的声道
  if(mn>0 && recFile) recFile.write((uint8_t*)mono, mn*2);
  pkL=pl; pkR=pr; recPeak=pl>pr?pl:pr; if(recPeak>recMaxPk)recMaxPk=recPeak;
  if(recFrames>=maxFrames) recStop();
}
void recStop(){
  recording=false; i2s_driver_uninstall(I2S_NUM_0);
  if(recFile){ uint32_t dataSz=recFrames*2;
    recFile.flush(); recFile.seek(4); w32(recFile,36+dataSz); recFile.seek(40); w32(recFile,dataSz);
    recFile.close(); }
  rescan();
}

// ---------- 绘制 ----------
// 统一页眉: 标题 + 分隔线 + 右上角小提示
void hdr(const char* title,const char* hint){
  ui.fillScreen(BG);
  ui.setTextColor(ACC); ui.setTextSize(2); ui.setCursor(8,6); ui.print(title);
  if(hint){ ui.setTextColor(GREY); ui.setTextSize(1); int w=strlen(hint)*6; ui.setCursor(236-w,8); ui.print(hint); }
  ui.drawFastHLine(0,25,240,LINE);
}
// 统一底部提示条
void footer(const char* hint){
  ui.drawFastHLine(0,116,240,LINE);
  ui.setTextColor(GREY); ui.setTextSize(1); ui.setCursor(8,122); ui.print(hint);
}
void drawMenu(){
  uiMake();
  ui.fillScreen(BG);
  // 标题块
  ui.setTextColor(ACC); ui.setTextSize(3); ui.setCursor(10,8); ui.print("STUDIO");
  ui.setTextColor(GREY); ui.setTextSize(1); ui.setCursor(12,34); ui.print("music machine");
  ui.drawFastHLine(0,46,240,LINE);
  const char* items[6]={"DOLL","SYNTH","SAMPLER","RECORDER","SONGS","LIBRARY"};
  for(int i=0;i<6;i++){ int col=i%2, row=i/2; int x=8+col*118, y=52+row*20;
    ui.fillRoundRect(x,y,112,17,3,CARD);
    ui.fillRoundRect(x+2,y+2,13,13,2,ACC); ui.setTextColor(BG); ui.setTextSize(1); ui.setCursor(x+6,y+5); ui.printf("%d",i+1);
    ui.setTextColor(INK); ui.setCursor(x+22,y+5); ui.print(items[i]); }
  char hint[40]; snprintf(hint,40, sdOK?"SD ok - %d wav    ` = back":"NO SD CARD", sN);
  footer(hint);
  ui.pushSprite(0,0);
}
void drawSampler(){
  hdr("SAMPLER","` menu");
  if(sN==0){ ui.setTextColor(HL); ui.setTextSize(2); ui.setCursor(20,56); ui.print("no wav on SD"); footer("put 16-bit WAV in /samples"); ui.pushSprite(0,0); return; }
  int pages=(sN+7)/8; if(pages<1)pages=1; if(sPage>=pages)sPage=pages-1;
  int base=sPage*8, shown=sN-base; if(shown>8)shown=8;
  // 大名字卡片
  ui.fillRoundRect(6,32,228,32,4,CARD);
  ui.setTextColor(sLoaded==sCur?INK:RED); ui.setTextSize(2); ui.setCursor(14,40); ui.print(sName[sCur]);
  ui.setTextSize(1); ui.setCursor(8,70);
  if(sLoaded!=sCur){ ui.setTextColor(RED); ui.print(loadDiag[0]?loadDiag:"LOAD FAIL"); }
  else { ui.setTextColor(GREY); ui.printf("sample %d/%d    page %d/%d", sCur+1, sN, sPage+1, pages); }
  int x0=8,gap=3,by=88,bw=(224-7*gap)/8;
  for(int i=0;i<shown;i++){ int x=x0+i*(bw+gap); int idx=base+i;
    if(idx==sCur){ ui.fillRoundRect(x,by,bw,18,3,ACC); ui.setTextColor(BG);}
    else{ ui.fillRoundRect(x,by,bw,18,3,CARD); ui.setTextColor(GREY);}
    ui.setTextSize(1); ui.setCursor(x+bw/2-3,by+6); ui.printf("%d",i+1); }
  footer("keys=play  ,/.=prev/next  1-8 pick  tab page");
  ui.pushSprite(0,0);
}
void drawRecorder(){
  hdr(recording?"REC":"RECORDER", recording?"":"` menu");
  if(recording){
    ui.fillCircle(214,12,5,RED);   // 红点闪
    float s=(millis()-recT0)/1000.0f;
    ui.setTextColor(HL); ui.setTextSize(3); ui.setCursor(14,40); ui.printf("%.1f",s);
    ui.setTextColor(GREY); ui.setTextSize(1); ui.setCursor(90,56); ui.printf("/ %ds",REC_MAX_SEC);
    int w=(int)(224.0f*recPeak/4000.0f); if(w>224)w=224;
    ui.drawRoundRect(8,76,228,18,3,LINE); ui.fillRect(10,78,w,14,recPeak>3500?RED:HL);
    ui.setTextColor(GREY); ui.setCursor(8,100); ui.printf("L=%ld R=%ld",(long)pkL,(long)pkR);
    footer("space = stop & save");
  } else {
    ui.setTextColor(INK); ui.setTextSize(1); ui.setCursor(8,40); ui.print(sdOK?"space = record    ok = play last":"NO SD CARD");
    ui.setTextColor(GREY); ui.setCursor(8,58); ui.print("speak to mic, saves to /samples/RECn.wav");
    if(recMaxPk>0){ ui.setTextColor(recMaxPk>200?HL:RED); ui.setCursor(8,76);
      ui.printf("last rec mic peak = %ld %s",(long)recMaxPk, recMaxPk>200?"(ok)":"(SILENT!)"); }
    if(diag[0]){ ui.setTextColor(ACC); ui.setCursor(8,92); ui.print(diag); }
    ui.setTextColor(GREY); ui.setCursor(150,92); ui.printf("free %luKB",(unsigned long)(ESP.getFreeHeap()/1024));
    if(recMsg[0]){ ui.setTextColor(RED); ui.setCursor(8,106); ui.print(recMsg); }
    footer("space record   ok play   ` menu");
  }
  ui.pushSprite(0,0);
}

// ---------- 录音库 (列表/播放/删除/改名) ----------
void libPlay(){ if(libSel<sN && loadWav(sPath[libSel])){ sLoaded=-1; audio.playFromBuffer(sBuf,sLen,sRate); } }
void libDelete(){ if(libSel<sN){ SD.remove(sPath[libSel]); rescan(); if(libSel>=sN)libSel=sN-1; if(libSel<0)libSel=0; } }
void libRename(){
  if(libSel>=sN||nameBuf[0]==0) return;
  char dir[72]; strncpy(dir,sPath[libSel],71); dir[71]=0;
  char* sl=strrchr(dir,'/'); if(!sl)return; *sl=0;            // 目录
  char np[96]; snprintf(np,sizeof(np),"%s/%s.wav",dir,nameBuf);
  SD.rename(sPath[libSel],np); rescan();
}
void drawLibrary(){
  hdr("LIBRARY","` menu");
  if(sN==0){ ui.setTextColor(HL); ui.setTextSize(2); ui.setCursor(20,56); ui.print("(no wav yet)"); footer("record some sounds first"); ui.pushSprite(0,0); return; }
  int rows=6, top=libSel-rows/2; if(top<0)top=0; if(top>sN-rows)top=sN-rows; if(top<0)top=0;
  for(int r=0;r<rows && top+r<sN;r++){ int i=top+r; int y=30+r*14;
    if(i==libSel){ ui.fillRoundRect(4,y-1,232,14,2,SEL); ui.setTextColor(BG);} else ui.setTextColor(INK);
    ui.setTextSize(1); ui.setCursor(10,y+2); ui.printf("%c %s", i==libSel?0x10:' ', sName[i]); }
  footer(";/. move  ok play  del delete  / rename");
  if(confirmDel){ ui.fillRoundRect(20,46,200,44,6,RED); ui.setTextColor(0xFFFF); ui.setTextSize(1);
    ui.setCursor(30,56); ui.printf("delete %s ?",sName[libSel]); ui.setCursor(30,72); ui.print("ok = YES    ` = no"); }
  if(renaming){ ui.fillRoundRect(16,44,208,48,6,SEL); ui.setTextColor(BG); ui.setTextSize(1);
    ui.setCursor(26,52); ui.print("rename (type, ok=save, `=cancel):"); ui.setTextColor(0xFFFF); ui.setTextSize(2);
    ui.setCursor(26,68); ui.printf("%s_",nameBuf); }
  ui.pushSprite(0,0);
}

// ---------- 乐曲库 (合成器存档) ----------
void loadSongNames(){ memset(songNames,0,sizeof(songNames));
  File f=SD.open("/songs/names.dat",FILE_READ); if(f){ f.read((uint8_t*)songNames,sizeof(songNames)); f.close();
    for(int i=0;i<NSLOT;i++) songNames[i][15]=0; } }
void saveSongNames(){ SD.mkdir("/songs"); File f=SD.open("/songs/names.dat",FILE_WRITE);
  if(f){ f.write((uint8_t*)songNames,sizeof(songNames)); f.close(); } }
void scanSongs(){ char p[32];
  for(int i=0;i<NSLOT;i++){ snprintf(p,32,"/songs/SONG%d.dat",i+1); songFilled[i]=SD.exists(p); }
  loadSongNames(); }
void drawSongs(){
  hdr("SONGS","` menu");
  int rows=6, top=songSel-rows/2; if(top<0)top=0; if(top>NSLOT-rows)top=NSLOT-rows; if(top<0)top=0;
  for(int r=0;r<rows && top+r<NSLOT;r++){ int i=top+r; int y=30+r*14;
    bool sel=(i==songSel);
    if(sel){ ui.fillRoundRect(4,y-1,232,14,2,SEL); }
    // 播放中标记
    if(i==previewSlot){ ui.setTextColor(sel?HL:HL); ui.setCursor(8,y+2); ui.print(">"); }
    char nm[20]; if(songFilled[i]&&songNames[i][0]) snprintf(nm,20,"%s",songNames[i]); else snprintf(nm,20,"SONG %d",i+1);
    ui.setTextColor(sel?BG:(songFilled[i]?INK:GREY)); ui.setTextSize(1);
    ui.setCursor(18,y+2); ui.print(nm);
    ui.setTextColor(sel?BG:GREY); ui.setCursor(186,y+2); ui.print(songFilled[i]?"saved":"empty"); }
  footer(";/. move  space play  ok edit  / name");
  if(renaming){ ui.fillRoundRect(16,44,208,48,6,SEL); ui.setTextColor(BG); ui.setTextSize(1);
    ui.setCursor(26,52); ui.print("name song (ok=save, `=cancel):"); ui.setTextColor(0xFFFF); ui.setTextSize(2);
    ui.setCursor(26,68); ui.printf("%s_",nameBuf); }
  ui.pushSprite(0,0);
}

void setup(){
  Wire.begin(8,9,400000);
  lcd.init(); lcd.setRotation(1);
  // 复古暖米色主题(与合成器统一)
  BG=lcd.color565(233,227,214); INK=lcd.color565(74,70,62); GREY=lcd.color565(150,144,130);
  ACC=lcd.color565(218,108,40); HL=lcd.color565(188,108,80); RED=lcd.color565(196,72,56);
  SEL=lcd.color565(120,110,92); CARD=lcd.color565(223,216,201); LINE=lcd.color565(196,189,174);
  kb.begin(&Wire,0x34);
  audio.begin(&Wire);
  sdSPI.begin(SD_SCK,SD_MISO,SD_MOSI,SD_CS);
  for(int hz=25000000; hz>=4000000 && !sdOK; hz/=2) sdOK=SD.begin(SD_CS,sdSPI,hz);
  if(sdOK) rescan();
  drawMenu();
}

void loop(){
  kb.update();
  if(st==MENU){
    if(kb.wasPressed("1")){ st=DOLL; uiFree(); if(sBuf){free(sBuf);sBuf=NULL;sLoaded=-1;} if(rBuf){free(rBuf);rBuf=NULL;} dollInit(); }
    else if(kb.wasPressed("2")){ st=SYNTH; uiFree(); if(sBuf){free(sBuf);sBuf=NULL;sLoaded=-1;} if(rBuf){free(rBuf);rBuf=NULL;} seqEnter(); }
    else if(kb.wasPressed("3")){ st=SAMPLER; if(rBuf){free(rBuf);rBuf=NULL;} if(sN&&sLoaded!=sCur){ if(loadWav(sPath[sCur]))sLoaded=sCur; } drawSampler(); }
    else if(kb.wasPressed("4")){ st=RECORDER; drawRecorder(); }
    else if(kb.wasPressed("5")){ st=SONGS; if(sBuf){free(sBuf);sBuf=NULL;sLoaded=-1;} if(rBuf){free(rBuf);rBuf=NULL;} scanSongs(); songSel=0; previewSlot=-1; renaming=false; drawSongs(); }
    else if(kb.wasPressed("6")){ st=LIBRARY; if(rBuf){free(rBuf);rBuf=NULL;} rescan(); libSel=0; confirmDel=false; renaming=false; drawLibrary(); }
    return;
  }
  // 通用返回 (改名时 ` 用作取消, 不退出)
  if(kb.wasPressed("`") && !(st==LIBRARY && (renaming||confirmDel)) && !(st==SONGS && renaming)){
    if(recording) recStop();
    if(st==DOLL) dollFree();
    if(st==SYNTH) seqExit();
    if(st==SONGS && seqIsPreviewing()){ seqPreviewStop(); previewSlot=-1; }
    st=MENU; drawMenu(); return;
  }
  if(st==SAMPLER){
    bool ch=false;
    int pages=(sN+7)/8; if(pages<1)pages=1;
    if(kb.wasPressed("tab")){ sPage=(sPage+1)%pages; drawSampler(); }
    if(kb.wasPressed(",")&&sN){ sCur=(sCur+sN-1)%sN; ch=true; }   // 上一个
    if(kb.wasPressed(".")&&sN){ sCur=(sCur+1)%sN; ch=true; }      // 下一个
    for(int i=0;i<8;i++){ char d[2]={(char)('1'+i),0}; int idx=sPage*8+i;
      if(idx<sN && kb.wasPressed(d)){ sCur=idx; ch=true; } }
    if(ch){ sPage=sCur/8; if(loadWav(sPath[sCur]))sLoaded=sCur; drawSampler(); }
    for(auto k:NOTEKEYS){ if(kb.wasPressed(k)){ int m=midiOfKey(k);
      if(m>=0 && sBuf && sLen){ uint32_t rate=(uint32_t)(sRate*powf(2.0f,(m-60)/12.0f));
        audio.playFromBuffer(sBuf,sLen,rate); } } }
  } else if(st==RECORDER){
    if(kb.wasPressed("space")){ if(!recording) recStart(); else recStop(); drawRecorder(); }
    if(kb.wasPressed("ok") && !recording && recPath[0]){ if(loadWav(recPath)){ sLoaded=-1; audio.playFromBuffer(sBuf,sLen,sRate); } }  // 试听(从卡读回)
    if(recording){ recPump(); static uint32_t last=0; if(millis()-last>100){ drawRecorder(); last=millis(); } }
  } else if(st==LIBRARY){
    if(renaming){
      // 文字输入: 字母数字追加, del=退格, ok=保存, ` =取消
      static const char* CH="abcdefghijklmnopqrstuvwxyz0123456789";
      for(const char* p=CH; *p; p++){ char s[2]={*p,0}; if(kb.wasPressed(s)){ int l=strlen(nameBuf); if(l<16){nameBuf[l]=*p;nameBuf[l+1]=0;} drawLibrary(); } }
      if(kb.wasPressed("del")){ int l=strlen(nameBuf); if(l>0)nameBuf[l-1]=0; drawLibrary(); }
      if(kb.wasPressed("ok")){ libRename(); renaming=false; drawLibrary(); }
      if(kb.wasPressed("`")){ renaming=false; drawLibrary(); }
    } else if(confirmDel){
      if(kb.wasPressed("ok")){ libDelete(); confirmDel=false; drawLibrary(); }
      if(kb.wasPressed("`")){ confirmDel=false; drawLibrary(); }
    } else {
      if(kb.wasPressed(";")){ if(libSel>0)libSel--; drawLibrary(); }
      if(kb.wasPressed(".")){ if(libSel<sN-1)libSel++; drawLibrary(); }
      if(kb.wasPressed("ok") && sN){ libPlay(); }
      if(kb.wasPressed("del") && sN){ confirmDel=true; drawLibrary(); }
      if(kb.wasPressed("/") && sN){ renaming=true; nameBuf[0]=0; drawLibrary(); }
    }
  } else if(st==DOLL){
    bool keyNow=false;
    static const char* L[]={"z","x","c","v","b","n","m","q","w","e","r","t","y","u","i","o","p","a","s","d","f","g","h","j","k","l","1","2","3","space"};
    for(auto k:L) if(kb.isHeld(k)){ keyNow=true; break; }
    dollRun(keyNow);
  } else if(st==SYNTH){
    seqLoop();
  } else if(st==SONGS){
    if(renaming){
      static const char* CH="abcdefghijklmnopqrstuvwxyz0123456789";
      for(const char* p=CH; *p; p++){ char s[2]={*p,0}; if(kb.wasPressed(s)){ int l=strlen(nameBuf); if(l<15){nameBuf[l]=*p;nameBuf[l+1]=0;} drawSongs(); } }
      if(kb.wasPressed("del")){ int l=strlen(nameBuf); if(l>0)nameBuf[l-1]=0; drawSongs(); }
      if(kb.wasPressed("ok")||kb.wasPressed("enter")){ strncpy(songNames[songSel],nameBuf,15); songNames[songSel][15]=0; saveSongNames(); renaming=false; drawSongs(); }
      if(kb.wasPressed("`")){ renaming=false; drawSongs(); }
    } else {
      if(kb.wasPressed(";")){ if(songSel>0){songSel--; if(seqIsPreviewing()){seqPreviewStop();previewSlot=-1;}} drawSongs(); }
      if(kb.wasPressed(".")){ if(songSel<NSLOT-1){songSel++; if(seqIsPreviewing()){seqPreviewStop();previewSlot=-1;}} drawSongs(); }
      if(kb.wasPressed("space") && songFilled[songSel]){
        if(seqIsPreviewing()){ seqPreviewStop(); previewSlot=-1; }
        else { if(sBuf){free(sBuf);sBuf=NULL;sLoaded=-1;} if(rBuf){free(rBuf);rBuf=NULL;} seqPreviewStart(songSel); previewSlot=songSel; }
        drawSongs(); }
      if(kb.wasPressed("/") && songFilled[songSel]){
        if(seqIsPreviewing()){ seqPreviewStop(); previewSlot=-1; }
        renaming=true; strncpy(nameBuf,songNames[songSel],15); nameBuf[15]=0; drawSongs(); }
      if((kb.wasPressed("ok")||kb.wasPressed("enter")) && songFilled[songSel]){
        if(seqIsPreviewing()){ seqPreviewStop(); previewSlot=-1; }
        st=SYNTH; uiFree(); if(sBuf){free(sBuf);sBuf=NULL;sLoaded=-1;} if(rBuf){free(rBuf);rBuf=NULL;}
        seqQueueLoad(songSel); seqEnter(); }
      if(seqIsPreviewing()) seqPreviewPump();
    }
  }
  // 菜单/列表页持续重推同一张离屏画布(像合成器那样), 抹掉单次推屏的撕裂闪烁
  if(st!=SYNTH && st!=DOLL && !(st==RECORDER&&recording) && ui.getBuffer()) ui.pushSprite(0,0);
  delay(8);
}
